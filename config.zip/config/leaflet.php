<?php

//philippines center

return [
    'zoom_level'           => 13,
    'detail_zoom_level'    => 13,
    'map_center_latitude'  => env('MAP_CENTER_LATITUDE', ' 14.6042'),  
    'map_center_longitude' => env('MAP_CENTER_LONGITUDE', '121.0359'),
];
