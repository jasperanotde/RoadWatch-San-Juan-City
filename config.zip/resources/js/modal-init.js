// Initialization for ES Users
import {
    Modal,
    Ripple,
    initTE,
  } from "tw-elements";
  
  initTE({ Modal, Ripple });

  console.log("Modal initialized."); 