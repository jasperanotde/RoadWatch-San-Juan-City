// Initialization for ES Users
import {
    Tab,
    initTE,
  } from "tw-elements";
  
  initTE({ Tab });